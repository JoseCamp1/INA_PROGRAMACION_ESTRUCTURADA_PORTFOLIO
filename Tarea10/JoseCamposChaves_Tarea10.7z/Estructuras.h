#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct cartas
{
	int numero ;
	string palo;
};

